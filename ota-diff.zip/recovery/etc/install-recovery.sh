#!/system/bin/sh
if ! applypatch -c EMMC:/dev/block/mmcblk0p6:8388608:1d129b74b3750b62e101f55e17c14efbc771106d; then
  log -t recovery "Installing new recovery image"
  applypatch EMMC:/dev/block/mmcblk0p5:7006208:c9fbdca7db6105f72c0788bb40d2213cd32d13a9 EMMC:/dev/block/mmcblk0p6 1d129b74b3750b62e101f55e17c14efbc771106d 8388608 c9fbdca7db6105f72c0788bb40d2213cd32d13a9:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
